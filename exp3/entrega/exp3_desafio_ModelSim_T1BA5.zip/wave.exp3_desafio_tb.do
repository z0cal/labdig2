# Layout das formas de onda do exp3_desafio_tb.

# Codigos dos displays de 7 segmentos mostrados como o digito exibido
radix define seg7 {
    7'b1000000 "0",
    7'b1111001 "1",
    7'b0100100 "2",
    7'b0110000 "3",
    7'b0011001 "4",
    7'b0010010 "5",
    7'b0000010 "6",
    7'b1111000 "7",
    7'b0000000 "8",
    7'b0010000 "9",
    7'b0001110 "F",
    -default binary
}

add wave -divider {Servomotor}
add wave -radix decimal sim:/exp3_desafio_tb/caso
add wave -radix binary  sim:/exp3_desafio_tb/posicao_in
add wave sim:/exp3_desafio_tb/controle_servo_out
add wave -radix binary  sim:/exp3_desafio_tb/db_posicao_out
add wave sim:/exp3_desafio_tb/db_controle_out

add wave -divider {Sensor de distancia}
add wave sim:/exp3_desafio_tb/reset_in
add wave sim:/exp3_desafio_tb/medir_in
add wave sim:/exp3_desafio_tb/trigger_out
add wave sim:/exp3_desafio_tb/echo_in
add wave sim:/exp3_desafio_tb/pronto_out
add wave -radix seg7 sim:/exp3_desafio_tb/db_estado_out
add wave -radix seg7 sim:/exp3_desafio_tb/hex2_out
add wave -radix seg7 sim:/exp3_desafio_tb/hex1_out
add wave -radix seg7 sim:/exp3_desafio_tb/hex0_out

configure wave -timelineunits ms
configure wave -signalnamewidth 1
