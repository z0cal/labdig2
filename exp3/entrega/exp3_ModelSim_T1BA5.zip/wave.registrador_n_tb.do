# Layout das formas de onda do registrador_n_tb (figuras do Planejamento).
add wave -radix decimal     sim:/registrador_n_tb/caso
add wave sim:/registrador_n_tb/clock_in
add wave sim:/registrador_n_tb/clear_in
add wave sim:/registrador_n_tb/enable_in
add wave -radix hexadecimal sim:/registrador_n_tb/d_in
add wave -radix hexadecimal sim:/registrador_n_tb/q_out

configure wave -timelineunits ns
configure wave -signalnamewidth 1
