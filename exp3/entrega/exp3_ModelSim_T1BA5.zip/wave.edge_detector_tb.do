# Layout das formas de onda do edge_detector_tb (figuras do Planejamento).
add wave -radix decimal sim:/edge_detector_tb/caso
add wave sim:/edge_detector_tb/clock_in
add wave sim:/edge_detector_tb/reset_in
add wave sim:/edge_detector_tb/sinal_in
add wave sim:/edge_detector_tb/dut/reg0
add wave sim:/edge_detector_tb/dut/reg1
add wave sim:/edge_detector_tb/pulso_out

configure wave -timelineunits ns
configure wave -signalnamewidth 1
