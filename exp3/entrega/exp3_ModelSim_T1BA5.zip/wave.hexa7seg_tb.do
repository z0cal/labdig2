# Layout das formas de onda do hexa7seg_tb (figuras do Planejamento).
add wave -radix hexadecimal sim:/hexa7seg_tb/hexa_in
add wave -radix binary      sim:/hexa7seg_tb/display_out
add wave -radix decimal     sim:/hexa7seg_tb/erros

configure wave -timelineunits ns
configure wave -signalnamewidth 1
