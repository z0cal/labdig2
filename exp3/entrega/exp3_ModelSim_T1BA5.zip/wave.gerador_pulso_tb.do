# Layout das formas de onda do gerador_pulso_tb (figuras do Planejamento).

# Estados do gerador_pulso pelo nome
radix define estados_gp {
    2'b00 "parado",
    2'b01 "contagem",
    2'b10 "final_pulso",
    -default binary
}

add wave -radix decimal    sim:/gerador_pulso_tb/caso
add wave sim:/gerador_pulso_tb/clock
add wave sim:/gerador_pulso_tb/reset
add wave sim:/gerador_pulso_tb/gera
add wave sim:/gerador_pulso_tb/para
add wave sim:/gerador_pulso_tb/pulso
add wave sim:/gerador_pulso_tb/pronto
add wave -radix estados_gp sim:/gerador_pulso_tb/dut/reg_estado
add wave -radix unsigned   sim:/gerador_pulso_tb/dut/reg_cont

configure wave -timelineunits us
configure wave -signalnamewidth 1
