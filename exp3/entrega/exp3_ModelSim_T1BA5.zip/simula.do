# simula.do — simula um testbench com o layout de formas de onda do
# Planejamento (wave.<testbench>.do).
#
# Uso (ModelSim/Questa, Transcript da GUI), na pasta com os arquivos .v:
#   do simula.do exp3_sensor_tb
# Sem argumento, simula interface_hcsr04_tb. Para todos: do simula_todos.do

onbreak {resume}
if {$argc > 0} { set tb $1 } else { set tb interface_hcsr04_tb }

# Fontes em rtl/ e tb/ (repositorio) ou todas na mesma pasta (ZIP de entrega)
set fontes [lsort -unique [concat [glob -nocomplain rtl/*.v] [glob -nocomplain tb/*.v] [glob -nocomplain *.v]]]
if {![file isdirectory work]} { vlib work }
vlog {*}$fontes

vsim -voptargs=+acc -onfinish stop work.$tb
if {[file exists wave.$tb.do]} { do wave.$tb.do } else { add wave sim:/$tb/* }
run -all
wave zoom full
