# Layout das formas de onda do exp3_sensor_tb (figuras do Planejamento).

# Codigos dos displays de 7 segmentos mostrados como o digito exibido
radix define seg7 {
    7'b1000000 "0",
    7'b1111001 "1",
    7'b0100100 "2",
    7'b0110000 "3",
    7'b0011001 "4",
    7'b0010010 "5",
    7'b0000010 "6",
    7'b1111000 "7",
    7'b0000000 "8",
    7'b0010000 "9",
    7'b0001000 "A",
    7'b0000011 "b",
    7'b1000110 "C",
    7'b0100001 "d",
    7'b0000110 "E",
    7'b0001110 "F",
    -default binary
}

add wave -divider {Chaves e sensor}
add wave -radix decimal sim:/exp3_sensor_tb/caso
add wave sim:/exp3_sensor_tb/reset_in
add wave sim:/exp3_sensor_tb/medir_in
add wave sim:/exp3_sensor_tb/dut/s_medir
add wave sim:/exp3_sensor_tb/trigger_out
add wave sim:/exp3_sensor_tb/echo_in

add wave -divider {Placa (LEDs, displays e GPIO)}
add wave sim:/exp3_sensor_tb/pronto_out
add wave -radix seg7 sim:/exp3_sensor_tb/db_estado_out
add wave -radix seg7 sim:/exp3_sensor_tb/hex2_out
add wave -radix seg7 sim:/exp3_sensor_tb/hex1_out
add wave -radix seg7 sim:/exp3_sensor_tb/hex0_out
add wave sim:/exp3_sensor_tb/db_medir_out
add wave sim:/exp3_sensor_tb/db_trigger_out
add wave sim:/exp3_sensor_tb/db_echo_out

configure wave -timelineunits ms
configure wave -signalnamewidth 1
