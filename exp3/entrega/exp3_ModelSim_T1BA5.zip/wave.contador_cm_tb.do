# Layout das formas de onda do contador_cm_tb (figuras do Planejamento).

# Estados da UC do contador_cm
radix define estados_cm {
    3'b000 "inicial",
    3'b001 "zerar",
    3'b010 "espera",
    3'b011 "conta_cm",
    3'b100 "fim",
    -default binary
}

add wave -radix decimal    sim:/contador_cm_tb/caso
add wave sim:/contador_cm_tb/reset_in
add wave sim:/contador_cm_tb/pulso_in
add wave -radix estados_cm sim:/contador_cm_tb/dut/UC/Eatual
add wave -radix unsigned   sim:/contador_cm_tb/dut/FD/U1/Q
add wave sim:/contador_cm_tb/dut/s_tick
add wave -radix unsigned   sim:/contador_cm_tb/digito2_out
add wave -radix unsigned   sim:/contador_cm_tb/digito1_out
add wave -radix unsigned   sim:/contador_cm_tb/digito0_out
add wave sim:/contador_cm_tb/fim_out
add wave sim:/contador_cm_tb/pronto_out

configure wave -timelineunits us
configure wave -signalnamewidth 1
