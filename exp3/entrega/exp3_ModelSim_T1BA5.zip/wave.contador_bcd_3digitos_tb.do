# Layout das formas de onda do contador_bcd_3digitos_tb (figuras do Planejamento).
add wave -radix decimal  sim:/contador_bcd_3digitos_tb/caso
add wave sim:/contador_bcd_3digitos_tb/clock
add wave sim:/contador_bcd_3digitos_tb/zera
add wave sim:/contador_bcd_3digitos_tb/conta
add wave -radix unsigned sim:/contador_bcd_3digitos_tb/digito2
add wave -radix unsigned sim:/contador_bcd_3digitos_tb/digito1
add wave -radix unsigned sim:/contador_bcd_3digitos_tb/digito0
add wave sim:/contador_bcd_3digitos_tb/fim
add wave -radix decimal  sim:/contador_bcd_3digitos_tb/valor_ref

configure wave -timelineunits ns
configure wave -signalnamewidth 1
