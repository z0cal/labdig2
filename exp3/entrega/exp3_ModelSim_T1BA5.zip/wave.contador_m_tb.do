# Layout das formas de onda do contador_m_tb (figuras do Planejamento).
add wave -radix decimal  sim:/contador_m_tb/caso
add wave sim:/contador_m_tb/clock_in
add wave sim:/contador_m_tb/zera_as_in
add wave sim:/contador_m_tb/zera_s_in
add wave sim:/contador_m_tb/conta_in
add wave -radix unsigned sim:/contador_m_tb/q_out
add wave sim:/contador_m_tb/meio_out
add wave sim:/contador_m_tb/fim_out

configure wave -timelineunits us
configure wave -signalnamewidth 1
