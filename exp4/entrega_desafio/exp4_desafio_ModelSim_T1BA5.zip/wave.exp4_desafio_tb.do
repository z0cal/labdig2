# Ondas do exp4_desafio_tb

radix define estado_uc {
    4'h0 "inicial",
    4'h1 "preparacao",
    4'h2 "dispara_medida",
    4'h3 "espera_medida",
    4'h4 "envia_char",
    4'h5 "espera_tx",
    4'h6 "proximo_char",
    4'h7 "espera_2",
    4'hF "final_trena",
    -default hex
}

radix define ascii7 {
    7'h23 "#",
    7'h30 "0", 7'h31 "1", 7'h32 "2", 7'h33 "3", 7'h34 "4",
    7'h35 "5", 7'h36 "6", 7'h37 "7", 7'h38 "8", 7'h39 "9",
    -default hex
}

set d sim:/exp4_desafio_tb/dut

add wave -divider Entradas_e_saidas
add wave -radix decimal sim:/exp4_desafio_tb/caso
add wave sim:/exp4_desafio_tb/reset_in
add wave sim:/exp4_desafio_tb/mensurar_in
add wave sim:/exp4_desafio_tb/trigger_out
add wave sim:/exp4_desafio_tb/echo_in
add wave sim:/exp4_desafio_tb/saida_serial_out
add wave sim:/exp4_desafio_tb/pronto_out
add wave -radix hex -label medida $d/s_medida

add wave -divider UC
add wave -radix estado_uc -label estado $d/U2_UC/Eatual
add wave -label mensurar_ed $d/s_mensurar_ed
add wave -label mede        $d/s_mede
add wave -label conta_char  $d/s_conta_char
add wave -label fim_char    $d/s_fim_char

add wave -divider Medida_dupla
add wave -label zera_med $d/s_zera_med
add wave -label seta_med $d/s_seta_med
add wave -label fim_med  $d/s_fim_med
add wave -label zera_2s  $d/s_zera_2s
add wave -label conta_2s $d/s_conta_2s
add wave -label fim_2s   $d/s_fim_2s
add wave -radix unsigned -label timer_2s $d/U3_FD/U5_TIMER_2S/Q
add wave -radix ascii7 -label ascii $d/U3_FD/s_dados_ascii
